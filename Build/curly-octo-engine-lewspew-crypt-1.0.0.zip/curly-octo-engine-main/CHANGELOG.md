# Changelog

## 1.0.0 — 2026-09-16
- Rebuilt `curly-octo-engine` as the LewSpEW Crypt engine.
- Added deterministic Instrument IR and synthesis graph compiler.
- Added spectral analysis with parabolic peak interpolation.
- Added Voodoo Water-style bounded nonlinear DSP with finite-value guard.
- Added corrected per-dimension FSQ reference implementation with `[8,5,5,5]` and 1000-code cardinality.
- Added SHA-256 Crypt manifest support.
- Added CLI, packaging metadata, examples, and regression tests.
- Kept optional ML/GPU dependencies out of the base install.
