# Forensic Validation

| Test | Status | Meaning |
|---|---|---|
| Import/package | IMPLEMENTED | Package imports from clean source tree |
| FSQ cardinality | IMPLEMENTED | `[8,5,5,5]` = 1000 combinations |
| Per-dimension FSQ | IMPLEMENTED | Each dimension uses its own level count |
| Deterministic compiler | IMPLEMENTED | Same prompt + seed gives same patch |
| Finite output guard | IMPLEMENTED | NaN/Inf input is sanitized before DSP |
| Sample ceiling | IMPLEMENTED | Output is bounded at configured sample ceiling |
| Spectral peak interpolation | IMPLEMENTED | Quadratic interpolation is used around detected peaks |
| CUDA/Triton | UNVERIFIED | Optional GPU path requires target hardware/runtime |
| True-peak compliance | REQUIRES-HOST-TESTING | Sample ceiling is not a certified dBTP measurement |
| DAW/plugin validation | BLOCKED | No native plugin target is included in this Python build |
